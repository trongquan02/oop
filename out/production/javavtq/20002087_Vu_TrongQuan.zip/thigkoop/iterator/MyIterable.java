package thigkoop.iterator;

public interface MyIterable {
	public Iterator createIterator();
}
