package thigkoop.mymath;

public class MyMath {
    static final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public MyMath() {
    }

    public  double cos(double x, int numTerms) {
        double cosx = 0;
        double term = 1;
        for (int i = 0; i <= numTerms; i++) {
            cosx += term;
            term *= (-1 * x * x) / ((2 * i + 1) * (2 * i + 2));
        }
        return cosx;
    }
    public static int Factorial(int number) {
        int factorial = 1;
        for (int i = 1; i <= number; i++) {
            factorial = factorial * i;
        }
        return factorial;
    }
    public  double exp(double x, int numTerm) {
        double s = 0;
        int i;
        for(i = 1;i <= numTerm; i++);
        s+=Math.pow(x,i)/Factorial(i);
        return s;
    }


    public static boolean isValiRadixString(String radixString, int index) {
        radixString = radixString.toLowerCase();
        for (int i = 0; i < radixString.length(); i++) {
            if ((Character.digit(radixString.charAt(i),index)) > 0) {
                continue;
            }
            return false;
        }
        return true;
    }
    public static int toRadixDigit(char ch, int n) {
        return Character.digit(ch, n);
    }
    public  int toDecimal(String number, int radix) {
        if (isValiRadixString(number, radix) == true) {
            int decimalValue = 0;
            for (int i = 0; i < number.length(); i++) {
                decimalValue = radix * decimalValue + toRadixDigit(number.charAt(i), radix);
            }
            return decimalValue;
        } else {
            return -1;
        }
    }

    public static int toInt(String str, int inRadix) {
        int result = 0;
        for (int charIdx = 0; charIdx < str.length(); charIdx++) {
            result = result * inRadix + Character.digit(str.charAt(charIdx), inRadix);
        }
        return result;
    }

    public static String toRadix(int num, int outRadix) {
        String result = "";
        while (num > 0) {
            result = ALPHABET.charAt(num % outRadix) + result;
            num /= outRadix;
            System.out.println(result);
        }
        return result;
    }

    public  String toRadix(String str, int inRadix, int outRadix) {
        if (inRadix == outRadix) {
            return str;
        }
        return toRadix(toInt(str, inRadix), outRadix);
    }
}
