package thigkoop.sortstrategy;

public class BubbleSort implements ISort {
    public BubbleSort() {
    }

    @Override
    public int sort(int[] data) {
        /* TODO */
        int count = 0;
        int length = data.length;
        for (int i = 0; i < length - 1; i++) {
            for (int j = 0; j < length - i - 1; j++) {
                if (data[j] > data[j + 1]) {
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                    count++;
                }
            }
        }
        return count;
    }
}
