package thigkoop.iterator;

import java.util.ArrayList;
public class MyList implements MyIterable {
	private ArrayList<String> menuItems;

	public MyList() {
		menuItems = new ArrayList<String>();
	}

	public void addItem(String name) {
		/* TODO */
		menuItems.add(name);
	}

	public ArrayList<String> getMenuItems() {
		/* TODO */
		ArrayList<String> list = new ArrayList<String>();
		for (String element : menuItems) {
			list.add(element);
		}
		return list;
	}

	public Iterator createIterator() {
		/* TODO */

	}

	public String toString() {
		/* TODO */
	}
}
