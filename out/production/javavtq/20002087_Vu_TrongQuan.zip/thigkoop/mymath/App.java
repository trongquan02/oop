package thigkoop.mymath;

public class App {
    public static void main(String[] args) {
        MyMath myMath = new MyMath();
        double cos =  myMath.cos(3.3, 100);
        double e = myMath.exp(2.2, 100);
        double number = cos * e;
        System.out.println(number);
    }
}
